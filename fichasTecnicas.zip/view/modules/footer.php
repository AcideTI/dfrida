<div class="container-fluid px-4">
  <div class="d-flex align-items-center justify-content-end small">
    <div class="text-muted">Copyright &copy; Todos los derechos reservados. D'Frida <?php echo date('Y'); ?></div>
    <div>
    </div>
  </div>
</div>