<?php

class TemplateController
{
  static public function ctrTemplate()
  {
    include "view/template.php";
  }
}